DAVID TECH SUPPLY — WEBSITE FILES
=================================

FILES
- index.html  Main website content
- style.css   Black, white and gold styling + mobile layout
- script.js   Catalogue filters, menu and WhatsApp enquiry form

BEFORE PUBLISHING
1. Open script.js in a text editor.
2. Find: const WHATSAPP_NUMBER = "2547XXXXXXXX";
3. Replace 2547XXXXXXXX with your real WhatsApp number in international format.
   Kenya example format: 2547XXXXXXXX (no + sign, spaces or dashes).
4. Save the file.
5. Open index.html in a browser to preview the website.

IMPORTANT BUSINESS DETAILS
- Prices are intentionally shown as "Request price"; add only prices you have confirmed.
- Product photos are illustrative. Replace them with your own genuine stock photos.
- Confirm model, storage, condition, battery health, SIM configuration, warranty,
  stock, shipping, customs and payment terms with each buyer before accepting an order.
- The enquiry form opens WhatsApp. It does not take payments or create orders automatically.

PUBLISH WITH GITHUB PAGES
1. Sign in at https://github.com
2. Click the + icon (top right) > New repository.
3. Repository name: david-tech-supply
4. Choose Public. Tick "Add a README file" if shown, then Create repository.
5. On the repository page, click Add file > Upload files.
6. Upload index.html, style.css and script.js (you can also upload README.txt).
   Upload the files themselves, not just the ZIP archive.
7. Click Commit changes.
8. Open Settings > Pages.
9. Under "Build and deployment", choose "Deploy from a branch".
10. Select branch "main" and folder "/ (root)", then Save.
11. Wait a few minutes and refresh Settings > Pages. GitHub will show your live website link.
   It will usually look like https://YOUR-USERNAME.github.io/david-tech-supply/

UPDATING YOUR WEBSITE
- To change text or products: open index.html in GitHub, click the pencil icon, edit, then Commit changes.
- To change colours/layout: edit style.css.
- To change WhatsApp number or form behaviour: edit script.js.
- To add a product: copy one complete <article class="product-card"...> block in index.html,
  update its model name, condition, image and enquiry link.
