// IMPORTANT: Replace this placeholder with your WhatsApp number in international format.
// Example for Kenya: 2547XXXXXXXX (do not include +, spaces or dashes).
const WHATSAPP_NUMBER = "2547XXXXXXXX";

const menuButton = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");
menuButton.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(open));
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => nav.classList.remove("open")));

document.querySelectorAll(".filter").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".filter").forEach(item => item.classList.remove("active"));
    button.classList.add("active");
    const filter = button.dataset.filter;
    document.querySelectorAll(".product-card").forEach(card => {
      card.hidden = filter !== "all" && card.dataset.condition !== filter;
    });
  });
});

document.querySelectorAll(".quote-link").forEach(link => {
  link.addEventListener("click", () => {
    const model = link.dataset.model;
    document.querySelector("#model").value = model;
  });
});

document.querySelector("#quote-form").addEventListener("submit", event => {
  event.preventDefault();
  if (WHATSAPP_NUMBER.includes("X")) {
    alert("Please add your real WhatsApp number in script.js first. See the README instructions.");
    return;
  }
  const data = {
    name: document.querySelector("#customer-name").value.trim(),
    phone: document.querySelector("#customer-phone").value.trim(),
    destination: document.querySelector("#destination").value.trim(),
    model: document.querySelector("#model").value,
    condition: document.querySelector("#condition").value,
    quantity: document.querySelector("#quantity").value,
    details: document.querySelector("#details").value.trim()
  };
  const message = `Hello DAVID TECH SUPPLY, I would like a wholesale quotation.\n\nName: ${data.name}\nMy WhatsApp: ${data.phone}\nDestination: ${data.destination}\nModel: ${data.model}\nCondition: ${data.condition}\nQuantity: ${data.quantity}\nStorage / details: ${data.details || "Please advise"}\n\nPlease confirm availability, specifications, total price and shipping options.`;
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`, "_blank", "noopener");
});

document.querySelector("#year").textContent = new Date().getFullYear();
